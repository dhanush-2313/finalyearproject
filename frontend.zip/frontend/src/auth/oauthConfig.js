export const oauthConfig = {
  googleClientId: process.env.GOOGLE_CLIENT_ID || "your-google-client-id",
  facebookAppId: process.env.FACEBOOK_APP_ID || "your-facebook-app-id",
}

